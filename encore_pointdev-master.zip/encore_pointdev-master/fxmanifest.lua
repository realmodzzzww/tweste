fx_version 'cerulean'
games      { 'gta5' }

--
-- Server
--

server_scripts {
    'server/server.lua',
}

--
-- Client
--

client_scripts {
    'client/client.lua',
}